<?php

$email = "mahmoudabassy611@gmail.com";

$deviceid = "3F3C987AD8C8E507";

?>
