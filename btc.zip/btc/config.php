<?php

$email = "mahmoudabassy611@gmail.com";

$deviceid = "mody2211611";

?>
