<?php

$email = "mahmoudabassy611@gmail.com";

$deviceid = "201A70D7721F8690";

?>
