<?php

$email = "xxxxxxxxxxxx";

$deviceid = "xxxxxxxxxxx";

?>
